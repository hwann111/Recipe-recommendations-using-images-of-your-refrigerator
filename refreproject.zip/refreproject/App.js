import App from './scr/App';

export default App;
